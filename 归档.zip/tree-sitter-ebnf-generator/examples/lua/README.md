This provides a not-yet working lua grammar. The grammar is copied from the
[lua manual](https://www.lua.org/manual/5.1/manual.html#8). It does not
correctly handle precedence yet.
