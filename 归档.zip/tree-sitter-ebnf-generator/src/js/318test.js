#!/usr/bin/env node

const acorn = require('acorn');
const walk = require('acorn-walk');
const fs = require('fs');

// 如果 v 是一个对象（规则引用），则返回其 value，且如果以 "_" 开头则去掉；如果是字符串，则加上单引号
function maybe_add_quotes(v) {
  if (typeof v === 'object') {
    let s = v.value ? v.value : v.toString();
    if (s.charAt(0) === '_') {
      s = s.substring(1);
    }
    return s;
  }
  if (typeof v === 'string') {
    return "'" + v + "'";
  }
  return String(v);
}

// 序列：将各部分用空格拼接，不自动加外层括号
function seq() {
  let parts = [];
  for (let i = 0; i < arguments.length; i++) {
    parts.push(maybe_add_quotes(arguments[i]));
  }
  let result = parts.join(" ");
  return { value: result };
}

// 选择：将所有选项用 " | " 拼接，并加上外层括号
function choice() {
  let parts = [];
  for (let i = 0; i < arguments.length; i++) {
    parts.push(maybe_add_quotes(arguments[i]));
  }
  return { value: '(' + parts.join(" | ") + ')' };
}

// 可选：如果参数中含空格（即由多个部分组成），则自动加上括号
function optional(arg) {
  let s = maybe_add_quotes(arg);
  if (s.indexOf(" ") >= 0 && !(s.startsWith("(") && s.endsWith(")"))) {
    s = "(" + s + ")";
  }
  return { value: s + "?" };
}

// 重复 0 次以上：同 optional 的处理逻辑
function repeat(arg) {
  let s = maybe_add_quotes(arg);
  if (s.indexOf(" ") >= 0 && !(s.startsWith("(") && s.endsWith(")"))) {
    s = "(" + s + ")";
  }
  return { value: s + "*" };
}

// 重复 1 次以上
function repeat1(arg) {
  let s = maybe_add_quotes(arg);
  if (s.indexOf(" ") >= 0 && !(s.startsWith("(") && s.endsWith(")"))) {
    s = "(" + s + ")";
  }
  return { value: s + "+" };
}

function alias(l, r) {
  return { value: '(' + maybe_add_quotes(l) + " -> " + maybe_add_quotes(r) + ')' };
}

// 处理优先级的辅助函数，内部会在表达式外加上一对括号（如果没有的话）
function _prec_impl(prefix, num, value) {
  prefix = prefix + (num !== undefined ? num : '');
  let valStr = (typeof value !== 'object')
    ? maybe_add_quotes(value)
    : (value.value ? value.value : value.toString());
  if (valStr.charAt(0) !== '(') {
    valStr = '(' + valStr + ')';
  }
  return { value: prefix + valStr };
}
function _prec(num, value) {
  return _prec_impl("", num, value);
}
function _token(value) {
  return _prec_impl("@", null, value);
}

// 注意：这里定义 token 为一个函数，满足 grammar.js 中 token(...) 的调用，同时挂载 token.immediate
function token(rule) {
  return _token(rule);
}
token.immediate = function(rule) {
  return _prec_impl("!", undefined, rule);
};

var prec = {
  right: function() {
    if (arguments.length === 1) {
      return _prec_impl(">", undefined, arguments[0]);
    } else {
      return _prec_impl(">", arguments[0], arguments[1]);
    }
  },
  left: function() {
    if (arguments.length === 1) {
      return _prec_impl("<", undefined, arguments[0]);
    } else {
      return _prec_impl("<", arguments[0], arguments[1]);
    }
  },
  dynamic: function() {
    if (arguments.length === 1) {
      return _prec_impl("~", undefined, arguments[0]);
    } else {
      return _prec_impl("~", arguments[0], arguments[1]);
    }
  }
};

// 右侧展开字符串，用于调试输出（这里大体保持原来逻辑）
function expandRhs(rhs, debug) {
  if (Array.isArray(rhs)) {
    let result = '{';
    for (let i = 0; i < rhs.length; i++) {
      let r = rhs[i];
      result += " " + (typeof r === 'object' && r.value ? r.value : Array.isArray(r) ? expandRhs(r) : maybe_add_quotes(r));
    }
    return result + (result.length > 1 ? ' }' : '}');
  } else if (typeof rhs === 'object') {
    return rhs.value ? rhs.value : rhs.toString();
  } else {
    return maybe_add_quotes(rhs);
  }
}

// 去掉首尾多余的括号
function cleanup(rhs) {
  if (rhs.charAt(0) === '(' && rhs.charAt(rhs.length - 1) === ')') {
    return rhs.substring(1, rhs.length - 1);
  }
  return rhs;
}

var $ = {};

// grammar() 接收语法定义对象后，先输出 externals、extras、word、conflicts（如果存在），再输出所有 rules
function grammar(parts) {
  let output = [];
  let rules = parts.rules || {};
  // 预注册所有规则名
  for (const key in rules) {
    $[key] = { value: key };
  }
  // 固定顺序输出常见非规则部分
  const nonRuleKeys = ["externals", "extras", "word", "conflicts"];
  nonRuleKeys.forEach(key => {
    if (parts[key]) {
      output.push(key.padEnd(10) + " ::= " + cleanup(expandRhs(parts[key]($), true)));
      output.push("");
    }
  });
  for (const key in parts) {
    if (key === "name" || key === "rules") continue;
    if (nonRuleKeys.indexOf(key) >= 0) continue;
    output.push(key.padEnd(10) + " ::= " + cleanup(expandRhs(parts[key]($), true)));
    output.push("");
  }
  output.push("rules:");
  for (const key in rules) {
    output.push(" " + key + " ::= " + cleanup(expandRhs(rules[key]($))));
  }
  console.log(output.join("\n"));
}

// 运行参数检查与文件读取
if (process.argv.length < 3) {
  console.error('Usage: specify filename');
  process.exit(1);
}

fs.readFile(process.argv[2], 'utf-8', function(err, data) {
  if (err) throw err;
  let parsed = acorn.parse(data, { ecmaVersion: 2020, sourceType: "module" });
  let constants = [];
  let grammarImpl = "";
  let functionsCode = "";
  let constString = "";
  walk.simple(parsed, {
    Program(p) {
      for (let index in p.body) {
        let node = p.body[index];
        if (node.type === 'VariableDeclaration' && node.kind === 'const') {
          let decl = node.declarations[0];
          let name = decl.id.name;
          if (decl.init && decl.init.properties) {
            for (let i in decl.init.properties) {
              let prop = decl.init.properties[i];
              constants.push({ name: (name + '.' + prop.key.name), value: prop.value.value });
            }
          }
          constString += data.substring(node.start, node.end) + "\n";
        } else if (node.type === 'ExpressionStatement') {
          let left = node.expression.left;
          if (!left || left.object.name !== 'module' || left.property.name !== 'exports') {
            console.error('Only module.exports is allowed (got ' + (left ? (left.object.name + '.' + left.property.name) : 'unknown') + ')');
            process.exit(1);
          }
          grammarImpl = data.substring(node.start, node.end)
            .replace(/prec\(/g, "_prec(")
            .replace(/token\(/g, "_token(");
        } else if (node.type === 'FunctionDeclaration') {
          functionsCode += data.substring(node.start, node.end)
            .replace(/prec\(/g, "_prec(")
            .replace(/token\(/g, "_token(") + "\n";
        }
      }
    }
  });
  walk.full(parsed, node => {
    if (node.type === 'MemberExpression') {
      if (node.object.name === '$') {
        let prop = node.property.name;
        $[prop] = { value: prop };
      }
    }
  });
  // 目前常量仍是内联处理
  let codeToEval = constString + functionsCode + grammarImpl;
  eval(codeToEval);
});

/**
 * Creates a rule to match one or more of the rules separated by `separator`
 *
 * @param {RuleOrLiteral} rule
 * @param {RuleOrLiteral} separator
 * @returns {SeqRule}
 */
function sep1(rule, separator) {
  return seq(rule, repeat(seq(separator, rule)));
}

/**
 * Creates a rule to match one or more of the rules separated by a comma
 *
 * @param {RuleOrLiteral} rule
 * @returns {SeqRule}
 */
function commaSep1(rule) {
  return seq(rule, repeat(seq(',', rule)));
}

/**
 * Creates a rule to optionally match one or more of the rules separated by a comma
 *
 * @param {RuleOrLiteral} rule
 * @returns {ChoiceRule}
 */
function commaSep(rule) {
  return optional(commaSep1(rule));
}
