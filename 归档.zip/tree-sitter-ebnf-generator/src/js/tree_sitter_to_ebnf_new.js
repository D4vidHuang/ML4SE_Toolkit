#!/usr/bin/env node

const acorn = require('acorn');
const walk = require('acorn-walk');
const fs = require('fs');

function print() {
  console.log.apply(this, arguments);
}

function maybe_add_quotes(v) {
  if (typeof v === 'object' && v !== null) {
    return v.value ? v.value : v.toString();
  } else if (typeof v === 'string') {
    return `'${v}'`;
  }
  return v !== undefined ? v.toString() : '';
}

function _prec_impl(prefix, num, value) {
  prefix = prefix + (num ? num : '');
  if (typeof value !== 'object') {
    value = maybe_add_quotes(value);
  } else {
    value = value.value ? value.value : value.toString();
  }
  const is_seq = value.charAt(0) === '(';
  return { value: prefix + (is_seq ? value : `(${value})`) };
}

function precFn() {
  if (arguments.length === 1) {
    return prec.dynamic(arguments[0]);
  } else if (arguments.length === 2) {
    return prec.dynamic(arguments[0], arguments[1]);
  }
}

const prec = function() {
  return precFn.apply(null, arguments);
};
prec.left = function() {
  if (arguments.length === 1) {
    return _prec_impl('<', undefined, arguments[0]);
  } else {
    return _prec_impl('<', arguments[0], arguments[1]);
  }
};
prec.right = function() {
  if (arguments.length === 1) {
    return _prec_impl('>', undefined, arguments[0]);
  } else {
    return _prec_impl('>', arguments[0], arguments[1]);
  }
};
prec.dynamic = function() {
  if (arguments.length === 1) {
    return _prec_impl('~', undefined, arguments[0]);
  } else {
    return _prec_impl('~', arguments[0], arguments[1]);
  }
};

function token(rule) {
  return _prec_impl('@', null, rule);
}
token.immediate = function(rule) {
  return _prec_impl('!', undefined, rule);
};

function field(name, rule) {
  return { value: `(${maybe_add_quotes(rule)}: ${name})` };
}
function choice() {
  let result = '';
  for (const i in arguments) {
    if (result.length > 0) result += ' | ';
    result += maybe_add_quotes(arguments[i]);
  }
  return { value: `(${result})` };
}
function optional(arg) {
  return { value: `${maybe_add_quotes(arg)}?` };
}
function repeat(arg) {
  return { value: `${maybe_add_quotes(arg)}*` };
}
function repeat1(arg) {
  return { value: `${maybe_add_quotes(arg)}+` };
}
function alias(l, r) {
  return { value: `(${maybe_add_quotes(l)} -> ${maybe_add_quotes(r)})` };
}
function seq() {
  let result = '';
  for (const i in arguments) {
    if (result.length > 1) result += ' ';
    result += maybe_add_quotes(arguments[i]);
  }
  return { value: arguments.length > 1 ? `(${result})` : result };
}

function sep1(rule, separator) {
  return seq(rule, repeat(seq(separator, rule)));
}
function commaSep(rule) {
  return optional(commaSep1(rule));
}
function commaSep1(rule) {
  return seq(rule, repeat(seq(',', rule)));
}

function expandRhs(rhs) {
  if (Array.isArray(rhs)) {
    let result = '{';
    for (const r of rhs) {
      if (typeof r === 'object' && r !== null) {
        result += ' ' + (r.value ? r.value : expandRhs(r));
      } else {
        result += ' ' + maybe_add_quotes(r);
      }
    }
    return result + (result.length > 1 ? ' }' : '}');
  } else if (typeof rhs === 'object' && rhs !== null) {
    return rhs.value || rhs.toString();
  } else {
    return maybe_add_quotes(rhs);
  }
}

function cleanup(rhs) {
  if (rhs.startsWith('(') && rhs.endsWith(')')) {
    return rhs.slice(1, -1);
  }
  return rhs;
}

var $ = {};

function grammar(parts) {
  const rules = parts.rules;
  for (const key in rules) {
    $[key] = { value: key };
  }

  // 输出非 rules 部分的语法现象，每条末尾追加分号
  for (const key in parts) {
    if (key === 'name' || key === 'rules') continue;
    const expanded = expandRhs(parts[key]($));
    print(`${key} ::= ${cleanup(expanded)};`);
    print('');
  }

  print('rules:');
  // 输出 rules 部分的语法规则，每条末尾追加分号
  for (const key in rules) {
    const expanded = expandRhs(rules[key]($));
    print(` ${key} ::= ${cleanup(expanded)};`);
  }
}

const filename = process.argv[2];
if (!filename) {
  console.error('Usage: node convert-to-ebnf.js /path/to/grammar.js');
  process.exit(1);
}

fs.readFile(filename, 'utf-8', (err, data) => {
  if (err) throw err;

  const parsed = acorn.parse(data, { ecmaVersion: 2020 });
  let grammarImpl = '';
  let constString = '';
  let functions = '';

  walk.simple(parsed, {
    Program(program) {
      for (const node of program.body) {
        if (node.type === 'VariableDeclaration' && node.kind === 'const') {
          constString += data.substring(node.start, node.end) + '\n';
        }
        else if (node.type === 'ExpressionStatement') {
          if (
            node.expression?.left?.object?.name === 'module' &&
            node.expression?.left?.property?.name === 'exports'
          ) {
            grammarImpl = data.substring(node.start, node.end);
          }
        }
        else if (node.type === 'FunctionDeclaration') {
          functions += data.substring(node.start, node.end) + '\n';
        }
      }
    }
  });

  const codeToEval = `
    ${constString}
    ${functions}
    ${grammarImpl}
  `;

  (function() {
    const localModule = { exports: {} };

    const localScope = {
      module: localModule,
      exports: localModule.exports,
      prec,
      token,
      field,
      choice,
      optional,
      repeat,
      repeat1,
      alias,
      seq,
      sep1,
      commaSep,
      commaSep1,
      grammar
    };

    const fn = new Function(...Object.keys(localScope),
      `"use strict";\n${codeToEval}`
    );

    fn(...Object.values(localScope));

  })();
});
