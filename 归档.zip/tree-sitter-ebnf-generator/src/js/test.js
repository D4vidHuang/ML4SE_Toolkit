#!/usr/bin/env node

const acorn = require('acorn');
const walk = require('acorn-walk');
const fs = require('fs');

// 简单输出函数
function print() { console.log.apply(this, arguments); }

// 如果规则名以 "_" 开头，则去掉前导下划线
function fixKey(key) {
  return key.startsWith('_') ? key.slice(1) : key;
}

// 定义一组被认为是“常量”的名称，输出时使用 ":=" 而非 "::="
const constantKeys = new Set([
  "upperChars", "lowerChars1", "lowerChars2", "lowerChars3", "lowerChars",
  "letter", "paren", "opchar", "unicodeEscape", "charEscapeSeq", "escapeSeq",
  "idrest", "varidRegex", "[v]arid", "boundvarid", "charNoBQOrNL", "plainid",
  "idRegex", "identifier", "decimalNumeral", "hexNumeral", "hexDigit", "fpLit1",
  "fpLit2", "fpLit3", "fpLit4", "exponentPart", "floatType", "booleanLiteral",
  "characterLiteral", "rawString", "stringLiteral", "string", "charMinusQuoteDollar",
  "[i]nterpolatedString", "[e]scape", "alphaid", "symbolLiteral", "comment", "nl", "semi", "id"
]);

// 根据 key 判断使用哪种分隔符：对于 rules 内的总是 "::="；其它如果属于常量则用 ":="，否则用 "::="
function operatorForKey(key, isRule = false) {
  if (isRule) return " ::= ";
  let fixed = fixKey(key);
  return constantKeys.has(fixed) ? " := " : " ::= ";
}

// 对于简单的标识符，保持原样（不添加引号）
function maybe_add_quotes(v) {
  if (typeof v !== 'object' && typeof v === 'string') {
    // 如果已经是正则字面量或被引号包裹则直接返回
    if ((v.startsWith('/') && v.endsWith('/')) ||
        (v.startsWith('"') && v.endsWith('"')) ||
        (v.startsWith("'") && v.endsWith("'"))) {
      return v;
    }
    return v; // 对于标识符不添加引号
  }
  return (v.value ? v.value : v.toString());
}

function _prec_impl(prefix, num, value) {
  prefix = prefix + (num ? num : '');
  if (typeof value !== 'object') {
    value = maybe_add_quotes(value);
  } else {
    value = value.value ? value.value : value.toString();
  }
  const is_seq = value.charAt(0) === '(';
  return { value: prefix + (is_seq ? value : "(" + value + ")") };
}
function _prec(num, value) { return _prec_impl("", num, value); }
function _token(value) { return _prec_impl("@", null, value); }

var prec = {
  right: function() {
    return arguments.length === 1
      ? _prec_impl(">", undefined, arguments[0])
      : _prec_impl(">", arguments[0], arguments[1]);
  },
  left: function() {
    return arguments.length === 1
      ? _prec_impl("<", undefined, arguments[0])
      : _prec_impl("<", arguments[0], arguments[1]);
  },
  dynamic: function() {
    return arguments.length === 1
      ? _prec_impl("~", undefined, arguments[0])
      : _prec_impl("~", arguments[0], arguments[1]);
  }
};

var token = {
  immediate: function(rule) {
    return _prec_impl("!", undefined, rule);
  }
};

function field(name, rule) {
  return { value: '(' + maybe_add_quotes(rule) + ": " + name + ')' };
}

function choice() {
  let result = "";
  for (let i in arguments) {
    if (result.length > 0) result += " | ";
    result += maybe_add_quotes(arguments[i]);
  }
  return { value: '(' + result + ')' };
}

function optional(arg) {
  return { value: maybe_add_quotes(arg) + "?" };
}

function repeat(arg) {
  return { value: maybe_add_quotes(arg) + "*" };
}

function repeat1(arg) {
  return { value: maybe_add_quotes(arg) + "+" };
}

function alias(l, r) {
  return { value: '(' + maybe_add_quotes(l) + " -> " + maybe_add_quotes(r) + ')' };
}

function seq() {
  let result = "";
  for (let i in arguments) {
    if (result.length > 0) result += " ";
    result += maybe_add_quotes(arguments[i]);
  }
  if (arguments.length > 1 || (arguments[1] && arguments[1].toString().indexOf(" ") >= 0))
    result = '(' + result + ')';
  return { value: result };
}

function expandRhs(rhs, debug) {
  if (rhs instanceof Array) {
    let result = '{';
    for (const k in rhs) {
      const r = rhs[k];
      result += " " + (typeof r === 'object' && r.value ? r.value : r instanceof Array ? expandRhs(r) : maybe_add_quotes(r));
    }
    return result + (result.length > 1 ? ' }' : '}');
  } else if (typeof rhs === 'object') {
    return rhs.value ? rhs.value : rhs.toString();
  } else {
    return maybe_add_quotes(rhs);
  }
}

function cleanup(rhs) {
  if (rhs.charAt(0) === '(' && rhs.charAt(rhs.length - 1) === ')') {
    return rhs.substring(1, rhs.length - 1);
  }
  return rhs;
}

var $ = {};

// grammar 函数将非 rules 部分与 rules 部分分别输出，新版格式化时会对规则名称去掉下划线并对常量使用不同的运算符
function grammar(parts) {
  const rules = parts.rules;
  // 输出非 rules 部分
  for (const key in parts) {
    if (key === 'name' || key === 'rules') continue;
    const fixedKey = fixKey(key);
    const op = operatorForKey(key, false);
    const rhs = cleanup(expandRhs(parts[key]($), true));
    print(fixedKey.padEnd(20) + op + rhs);
    print("");
  }
  print("rules:");
  for (const key in rules) {
    const fixedKey = fixKey(key);
    const op = operatorForKey(key, true); // rules统一用 "::="
    const rhs = cleanup(expandRhs(rules[key]($)));
    print(" " + fixedKey.padEnd(20) + op + rhs);
  }
}

// 读取指定文件并解析成 AST，再从中提取常量、函数和 module.exports 部分
fs.readFile(process.argv[2], 'utf-8', function(err, data) {
  if (err) throw err;
  const parsed = acorn.parse(data, { ecmaVersion: 2020 });
  let constants = [];
  let grammarImpl;
  let functions = "";
  let constString = "";

  walk.simple(parsed, {
    Program(p) {
      for (let index in p.body) {
        const node = p.body[index];
        if (node.type === 'VariableDeclaration' && node.kind === 'const') {
          const decl = node.declarations[0];
          const name = decl.id.name;
          // 将对象字面量中的每个属性视为常量
          for (let i in decl.init.properties) {
            const prop = decl.init.properties[i];
            constants.push({ name: fixKey(name + '.' + prop.key.name), value: prop.value.value });
          }
          constString += data.substring(node.start, node.end) + "\n";
        } else if (node.type === 'ExpressionStatement') {
          const left = node.expression.left;
          const name = left.object.name;
          const prop = left.property.name;
          if (name !== 'module' || prop !== 'exports') {
            print('Only module.exports is allowed (got ' + name + '.' + prop + ')');
            throw "";
          }
          // 将 prec/token 调用替换为内部实现
          grammarImpl = data.substring(node.start, node.end)
            .replaceAll("prec(", "_prec(")
            .replaceAll("token(", "_token(");
        } else if (node.type === 'FunctionDeclaration') {
          functions += data.substring(node.start, node.end)
            .replaceAll("prec(", "_prec(")
            .replaceAll("token(", "_token(") + "\n";
        } else {
          print("unexpected type '" + node.type + "' for node:", node);
          throw "";
        }
      }
    }
  });

  // 将类似 $.xxx 的成员表达式转为 {value: "xxx"}
  walk.full(parsed, node => {
    if (node.type === 'MemberExpression' && node.object.name === '$') {
      const prop = node.property.name;
      $[prop] = { value: prop };
    }
  });

  // 执行收集的常量、函数和 module.exports 代码以生成最终 grammar
  eval(constString + functions + grammarImpl);
});
